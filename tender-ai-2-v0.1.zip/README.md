# Tender AI 2.0

Минимальная облачная сборка Tender AI для Telegram.

## Render
Build Command:
`pip install -r requirements.txt`

Start Command:
`uvicorn app.main:app --host 0.0.0.0 --port $PORT`

Health Check:
`/healthz`

Environment Variable:
`TELEGRAM_BOT_TOKEN`
