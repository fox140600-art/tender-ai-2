import os

TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
APP_NAME = os.getenv("APP_NAME", "Tender AI 2.0")
