from fastapi import FastAPI, Request, HTTPException
import httpx

from app.config import TELEGRAM_BOT_TOKEN, APP_NAME
from app.rules.reglament import REGULATION_VERSION

app = FastAPI(title=APP_NAME)

def telegram_api(method: str) -> str:
    if not TELEGRAM_BOT_TOKEN:
        raise RuntimeError("TELEGRAM_BOT_TOKEN is not configured")
    return f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/{method}"

async def send_message(chat_id: int, text: str):
    async with httpx.AsyncClient(timeout=20) as client:
        await client.post(
            telegram_api("sendMessage"),
            json={"chat_id": chat_id, "text": text},
        )

@app.get("/")
async def root():
    return {"service": APP_NAME, "status": "ok"}

@app.get("/healthz")
async def healthz():
    return {"status": "ok", "service": APP_NAME}

@app.post("/telegram/webhook")
async def telegram_webhook(request: Request):
    update = await request.json()
    message = update.get("message") or update.get("edited_message")
    if not message:
        return {"ok": True}

    chat = message.get("chat", {})
    chat_id = chat.get("id")
    text = (message.get("text") or "").strip()

    if not chat_id:
        return {"ok": True}

    if text.startswith("/start"):
        reply = (
            "Tender AI 2.0 запущен.\n\n"
            "Команды:\n"
            "/status — состояние системы\n"
            "/reglament — версия регламента\n"
            "/help — помощь"
        )
    elif text.startswith("/status"):
        reply = "✅ Tender AI 2.0 работает. Backend: OK."
    elif text.startswith("/reglament"):
        reply = f"📘 Активный регламент: {REGULATION_VERSION}"
    elif text.startswith("/help"):
        reply = (
            "Пока доступна базовая версия. "
            "Следом подключим память, тендерные карточки, ИИ-анализ и поставщиков."
        )
    else:
        reply = "Сообщение получено. ИИ-модуль подключим на следующем этапе."

    await send_message(chat_id, reply)
    return {"ok": True}
